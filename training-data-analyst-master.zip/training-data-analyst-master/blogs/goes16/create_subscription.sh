#!/bin/bash
gcloud beta pubsub subscriptions create testsubscription --topic=projects/gcp-public-data---goes-16/topics/gcp-public-data-goes-16
