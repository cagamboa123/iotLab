#!/bin/bash
gcloud beta pubsub subscriptions delete testsubscription
