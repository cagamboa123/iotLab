#!/bin/bash
sudo pip install pandas-gbq==0.4.1
