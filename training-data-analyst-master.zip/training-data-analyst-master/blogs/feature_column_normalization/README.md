## Feature normalization in TensorFlow
Code accompanying blog post on feature normalization.
