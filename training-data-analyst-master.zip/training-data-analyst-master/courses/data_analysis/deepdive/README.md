

1. Download data:
gsutil -m cp gs://cloud-training-demos/datasme/pubsub/actions.csv pubsub-exercises/data/actions.csv

2. PubSub exercises:
https://codelabs.developers.google.com/codelabs/datasme-pubsub-01

3. Bigtable exercises:
https://codelabs.developers.google.com/codelabs/datasme-bigtable-01

4. BigQuery exercises:
https://codelabs.developers.google.com/codelabs/datasme-bigquery-01

5. Cloud Composer exercises:
https://codelabs.developers.google.com/codelabs/datasme-composer-01
