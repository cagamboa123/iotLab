#!/bin/bash
gsutil -m cp gs://cloud-bigtable-training/actions_subset.csv src/main/resources/actions_subset.csv