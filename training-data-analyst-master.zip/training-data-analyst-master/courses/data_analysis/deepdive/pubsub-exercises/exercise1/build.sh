#!/bin/bash
mvn package
